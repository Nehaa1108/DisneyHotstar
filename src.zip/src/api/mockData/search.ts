// import { ContentItem, SearchSuggestion } from '../../types/content';

// export const trendingSearches: SearchSuggestion[] = [
//   { id: 's1', label: 'Rush Hour' },
//   { id: 's2', label: 'Waterworld' },
//   { id: 's3', label: "Charlie's Angels" },
//   { id: 's4', label: 'The Thin Red Line' },
//   { id: 's5', label: 'Repo Men' },
// ];

// export const searchableContent: ContentItem[] = Array.from({ length: 20 }, (_, i) => ({
//   id: `search-item-${i}`,
//   title: i % 3 === 0 ? `Crimson Series ${i}` : i % 3 === 1 ? `The Frontier Files ${i}` : `Match Highlights ${i}`,
//   posterUrl: `https://picsum.photos/seed/search${i}/300/450`,
//   genres: ['Drama'],
//   year: 2025,
//   rating: 'U/A 16+',
//   durationMinutes: 40,
//   description: 'Searchable mock content used to simulate query matching.',
// }));

export const searchableContent = [
  {
    id: "1",
    title: "Avengers Endgame",
    posterUrl: "https://picsum.photos/300/450?1",
    year: 2024,
    rating: "8.9",
    genres: ["Action"],
  },
  {
    id: "2",
    title: "The Boys",
    posterUrl: "https://picsum.photos/300/450?2",
    year: 2025,
    rating: "8.7",
    genres: ["Drama"],
  },
  {
    id: "3",
    title: "Loki",
    posterUrl: "https://picsum.photos/300/450?3",
    year: 2024,
    rating: "8.5",
    genres: ["Fantasy"],
  },
];