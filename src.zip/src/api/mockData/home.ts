// import { HomeFeed } from '../../types/content';

// export const mockHomeFeed: HomeFeed = {
//   heroBanners: [
//     {
//       id: 'hero-1',
//       title: 'The Last Frontier',
//       backdropUrl: 'https://image.tmdb.org/t/p/original/qZvAcvZyT4Duvi5kaPoNoJg2TT9',
//       tagline: 'New Season Streaming Now',
//     },
//     {
//       id: 'hero-2',
//       title: 'Crimson Tide',
//       backdropUrl: 'https://picsum.photos/seed/hero2/800/450',
//       tagline: 'Watch the Finale',
//     },
//     {
//       id: 'hero-3',
//       title: 'Midnight Express',
//       backdropUrl: 'https://picsum.photos/seed/hero3/800/450',
//       tagline: 'Only on Hotstar Clone',
//     },
//   ],
//   rows: [
//     {
//       id: 'row-trending',
//       title: 'Trending Now',
//       items: Array.from({ length: 8 }, (_, i) => ({
//         id: `trending-${i}`,
//         title: `Trending Show ${i + 1}`,
//         posterUrl: `https://picsum.photos/seed/trend${i}/300/450`,
//         genres: ['Drama', 'Thriller'],
//         year: 2025,
//         rating: 'U/A 16+',
//         durationMinutes: 45,
//         description: 'A gripping tale of suspense and intrigue that keeps you on edge.',
//       })),
//     },
//     {
//       id: 'row-sports',
//       title: 'Live Sports',
//       items: Array.from({ length: 6 }, (_, i) => ({
//         id: `sports-${i}`,
//         title: `Match ${i + 1}`,
//         posterUrl: `https://picsum.photos/seed/sport${i}/300/450`,
//         genres: ['Cricket'],
//         year: 2026,
//         isLive: i === 0,
//         description: 'Live coverage of the ongoing match with expert commentary.',
//       })),
//     },
//     {
//       id: 'row-movies',
//       title: 'Blockbuster Movies',
//       items: Array.from({ length: 8 }, (_, i) => ({
//         id: `movie-${i}`,
//         title: `Movie Title ${i + 1}`,
//         posterUrl: `https://picsum.photos/seed/movie${i}/300/450`,
//         genres: ['Action', 'Adventure'],
//         year: 2024,
//         rating: 'U/A 13+',
//         durationMinutes: 128,
//         description: 'An action-packed adventure across breathtaking landscapes.',
//       })),
//     },
//   ],
// };

import { HomeFeed, ContentItem } from '../../types/content';

const API_URL = 'https://jsonfakery.com/movies/paginated';

export async function fetchRealHomeFeed(): Promise<HomeFeed> {
  const response = await fetch(`${API_URL}?page=1`);
  const json = await response.json();
  const movies = json.data;

  // Map API movie shape → your ContentItem type
  const toContentItem = (movie: any): ContentItem => ({
    id: String(movie.movie_id),
    title: movie.original_title,
    posterUrl: movie.poster_path,
    backdropUrl: movie.backdrop_path,
    genres: movie.casts?.slice(0, 2).map((c: any) => c.character) ?? [],
    year: movie.release_date
      ? new Date(movie.release_date).getFullYear()
      : 2024,
    rating: movie.vote_average ? `${movie.vote_average.toFixed(1)} ⭐` : undefined,
    durationMinutes: undefined,
    isLive: false,
    description: movie.overview,
  });

  // Use first 3 movies as hero banners
  const heroBanners = movies.slice(0, 3).map((movie: any) => ({
    id: `hero-${movie.movie_id}`,
    title: movie.original_title,
    backdropUrl: movie.backdrop_path,
    tagline: movie.overview.slice(0, 60) + '...',
  }));

  // Trending — first 8 movies
  const trending = movies.slice(0, 8).map(toContentItem);

  // Popular — next 6 movies (indices 8–13)
  const popular = movies.slice(8, 14).map((m: any) => ({
    ...toContentItem(m),
    isLive: false,
  }));

  // Blockbusters — remaining movies sorted by vote_average
  const blockbusters = [...movies]
    .sort((a: any, b: any) => b.vote_average - a.vote_average)
    .slice(0, 8)
    .map(toContentItem);

  return {
    heroBanners,
    rows: [
      { id: 'row-trending', title: 'Trending Now', items: trending },
      { id: 'row-popular', title: 'Popular on Hotstar', items: popular },
      { id: 'row-blockbusters', title: 'Top Rated Movies', items: blockbusters },
    ],
  };
}