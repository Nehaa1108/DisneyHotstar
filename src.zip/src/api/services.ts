// import { HomeFeed } from '../types/content';
// import { mockHomeFeed } from './mockData/home';
// import { ContentItem, SearchSuggestion } from '../types/content';
// import { trendingSearches, searchableContent } from './mockData/search';
// import { UserProfile, mockUserProfile, mockMenuItems, ProfileMenuItem } from './mockData/profile';


// export async function prepareApp(): Promise<void> {
//   await new Promise((resolve) => setTimeout(resolve, 600));
// }

// export async function fetchHomeFeed(): Promise<HomeFeed> {
//   await new Promise((resolve) => setTimeout(resolve, 900));
//   return mockHomeFeed;
// }


// export async function fetchTrendingSearches(): Promise<SearchSuggestion[]> {
//   await new Promise((resolve) => setTimeout(resolve, 400));
//   return trendingSearches;
// }

// export async function searchContent(query: string): Promise<ContentItem[]> {
//   await new Promise((resolve) => setTimeout(resolve, 500));
//   const normalized = query.trim().toLowerCase();
//   if (!normalized) return [];
//   return searchableContent.filter((item) =>
//     item.title.toLowerCase().includes(normalized)
//   );
// }


// export async function fetchUserProfile(): Promise<UserProfile> {
//   await new Promise((resolve) => setTimeout(resolve, 600));
//   return mockUserProfile;
// }

// export async function fetchMenuItems(): Promise<ProfileMenuItem[]> {
//   await new Promise((resolve) => setTimeout(resolve, 300));
//   return mockMenuItems;
// }







import { HomeFeed } from '../types/content';
import { fetchRealHomeFeed } from './mockData/home';
import { UserProfile, mockUserProfile, mockMenuItems, ProfileMenuItem } from './mockData/profile';

export async function prepareApp(): Promise<void> {
  await new Promise((resolve) => setTimeout(resolve, 600));
}

export async function fetchHomeFeed(): Promise<HomeFeed> {
  return fetchRealHomeFeed(); 
}

export async function fetchTrendingSearches() {
  await new Promise((resolve) => setTimeout(resolve, 400));
  return [
    { id: 's1', label: 'Rush Hour' },
    { id: 's2', label: 'Waterworld' },
    { id: 's3', label: 'Charlie\'s Angels' },
    { id: 's4', label: 'The Thin Red Line' },
    { id: 's5', label: 'Repo Men' },
  ];
}

export async function searchContent(query: string) {
  await new Promise((resolve) => setTimeout(resolve, 500));
  const { fetchRealHomeFeed: _ } = await import('./mockData/home');
  const feed = await fetchRealHomeFeed();
  const all = feed.rows.flatMap(r => r.items);
  const normalized = query.trim().toLowerCase();
  return all.filter(item => item.title.toLowerCase().includes(normalized));
}

export async function fetchUserProfile(): Promise<UserProfile> {
  await new Promise((resolve) => setTimeout(resolve, 600));
  return mockUserProfile;
}

export async function fetchMenuItems(): Promise<ProfileMenuItem[]> {
  await new Promise((resolve) => setTimeout(resolve, 300));
  return mockMenuItems;
}