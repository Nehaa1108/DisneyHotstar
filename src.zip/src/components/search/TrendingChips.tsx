

// import { View, Text, TouchableOpacity } from 'react-native';
// import { SearchSuggestion } from '../../types/content';

// interface TrendingChipsProps {
//   items: SearchSuggestion[];
//   onSelect: (label: string) => void;
// }

// export default function TrendingChips({ items, onSelect }: TrendingChipsProps) {
//   return (
//     <View className="px-4 mt-6">
//       <Text className="text-white text-base font-semibold mb-3">
//         Trending Searches
//       </Text>
//       <View className="flex-row flex-wrap gap-2">
//         {items.map((item) => (
//           <TouchableOpacity
//             key={item.id}
//             className="bg-surface px-3.5 py-2 rounded-full border border-border"
//             onPress={() => onSelect(item.label)}
//             activeOpacity={0.7}
//           >
//             <Text className="text-white text-[13px]">{item.label}</Text>
//           </TouchableOpacity>
//         ))}
//       </View>
//     </View>
//   );
// }

import { View, Text, TouchableOpacity } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { SearchSuggestion } from "../../types/content";

interface Props {
  items: SearchSuggestion[];
  onSelect: (text: string) => void;
}

export default function TrendingChips({
  items,
  onSelect,
}: Props) {
  return (
    <View className="mt-6 px-4">

      <Text className="text-white text-xl font-bold mb-5">
        🔥 Trending Searches
      </Text>

      {items.map((item, index) => (
        <TouchableOpacity
          key={item.id}
          activeOpacity={0.8}
          onPress={() => onSelect(item.label)}
          className="flex-row items-center justify-between border-b border-zinc-800 py-4"
        >

          <View className="flex-row items-center">

            <Text className="text-red-500 font-bold text-lg mr-4">
              {index + 1}
            </Text>

            <Text className="text-white text-base font-medium">
              {item.label}
            </Text>

          </View>

          <Ionicons
            name="chevron-forward"
            size={18}
            color="#777"
          />

        </TouchableOpacity>
      ))}

    </View>
  );
}