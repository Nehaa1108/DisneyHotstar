// import { useEffect } from 'react';
// import { StyleSheet, ViewStyle, View, useWindowDimensions } from 'react-native';
// import Animated, {
//   useSharedValue,
//   useAnimatedStyle,
//   withRepeat,
//   withTiming,
//   Easing,
// } from 'react-native-reanimated';
// import { LinearGradient } from 'expo-linear-gradient';
// import { colors } from '../../theme/colors';

// interface SkeletonProps {
//   style?: ViewStyle;
// }

// export default function Skeleton({ style }: SkeletonProps) {
//   const { width: screenWidth } = useWindowDimensions();
//   const sweepWidth = 150;
//   const translateX = useSharedValue(-sweepWidth);

//   useEffect(() => {
//     translateX.value = withRepeat(
//       withTiming(screenWidth + sweepWidth, { duration: 1300, easing: Easing.linear }),
//       -1,
//       false
//     );
//   }, [screenWidth]);

//   const animatedStyle = useAnimatedStyle(() => ({
//     transform: [{ translateX: translateX.value }],
//   }));

//   return (
//     <View style={[styles.base, style]}>
//       <Animated.View style={[StyleSheet.absoluteFill, animatedStyle]}>
//         <LinearGradient
//           colors={['transparent', 'rgba(255,255,255,0.08)', 'transparent']}
//           start={{ x: 0, y: 0 }}
//           end={{ x: 1, y: 0 }}
//           style={[styles.gradient, { width: sweepWidth }]}
//         />
//       </Animated.View>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   base: {
//     backgroundColor: colors.surface,
//     borderRadius: 8,
//     overflow: 'hidden',
//   },
//   gradient: {
//     height: '100%',
//   },
// });


import { useEffect } from 'react';
import { ViewStyle, View, useWindowDimensions } from 'react-native';
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';
import { LinearGradient } from 'expo-linear-gradient';

interface SkeletonProps {
  style?: ViewStyle;
}

export default function Skeleton({ style }: SkeletonProps) {
  const { width: screenWidth } = useWindowDimensions();
  const sweepWidth = 150;
  const translateX = useSharedValue(-sweepWidth);

  useEffect(() => {
    translateX.value = withRepeat(
      withTiming(screenWidth + sweepWidth, { duration: 1300, easing: Easing.linear }),
      -1,
      false
    );
  }, [screenWidth]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateX: translateX.value }],
  }));

  return (
   
    <View className="bg-surface rounded-lg overflow-hidden" style={style}>

     
      <Animated.View
        className="absolute inset-0"
        style={animatedStyle}
      >
        <LinearGradient
          colors={['transparent', 'rgba(255,255,255,0.08)', 'transparent']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 0 }}
          className="h-full"
          style={{ width: sweepWidth }} 
        />
      </Animated.View>

    </View>
  );
}