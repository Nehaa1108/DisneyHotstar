// import { View, StyleSheet } from 'react-native';
// import Skeleton from '../common/Skeleton';

// export default function ContentCardSkeleton() {
//   return (
//     <View style={styles.container}>
//       <Skeleton style={styles.poster} />
//       <Skeleton style={styles.title} />
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: { width: 110, marginRight: 12 },
//   poster: { width: 110, height: 165 },
//   title: { width: 80, height: 11, marginTop: 6 },
// });

import { View } from 'react-native';
import Skeleton from '../common/Skeleton';

export default function ContentCardSkeleton() {
  return (
    <View className="w-[110px] mr-3">
      <Skeleton style={{ width: 110, height: 165 }} />
      <Skeleton style={{ width: 80, height: 11, marginTop: 6 }} />
    </View>
  );
}