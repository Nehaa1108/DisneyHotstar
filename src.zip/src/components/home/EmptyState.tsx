// import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
// import { colors } from '../../theme/colors';

// interface EmptyStateProps {
//   title: string;
//   subtitle?: string;
//   actionLabel?: string;
//   onAction?: () => void;
// }

// export default function EmptyState({ title, subtitle, actionLabel, onAction }: EmptyStateProps) {
//   return (
//     <View style={styles.container}>
//       <Text style={styles.title}>{title}</Text>
//       {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
//       {actionLabel && onAction ? (
//         <TouchableOpacity style={styles.button} onPress={onAction}>
//           <Text style={styles.buttonText}>{actionLabel}</Text>
//         </TouchableOpacity>
//       ) : null}
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24 },
//   title: { color: colors.text, fontSize: 16, fontWeight: '600', textAlign: 'center' },
//   subtitle: { color: colors.textMuted, fontSize: 13, marginTop: 8, textAlign: 'center' },
//   button: {
//     marginTop: 16,
//     backgroundColor: colors.accent,
//     paddingHorizontal: 20,
//     paddingVertical: 10,
//     borderRadius: 8,
//   },
//   buttonText: { color: '#fff', fontWeight: '600' },
// });

import { View, Text, TouchableOpacity } from 'react-native';

interface EmptyStateProps {
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export default function EmptyState({ title, subtitle, actionLabel, onAction }: EmptyStateProps) {
  return (
    <View className="flex-1 justify-center items-center p-6">
      <Text className="text-white text-base font-semibold text-center">
        {title}
      </Text>

      {subtitle ? (
        <Text className="text-textMuted text-[13px] mt-2 text-center">
          {subtitle}
        </Text>
      ) : null}

      {actionLabel && onAction ? (
        <TouchableOpacity
          className="mt-4 bg-accent px-5 py-2.5 rounded-lg"
          onPress={onAction}
        >
          <Text className="text-white font-semibold">{actionLabel}</Text>
        </TouchableOpacity>
      ) : null}
    </View>
  );
}