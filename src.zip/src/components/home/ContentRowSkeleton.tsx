// import { View, StyleSheet } from 'react-native';
// import Skeleton from '../common/Skeleton';
// import ContentCardSkeleton from './ContentCardSkeleton';

// export default function ContentRowSkeleton() {
//   return (
//     <View style={styles.container}>
//       <Skeleton style={styles.title} />
//       <View style={styles.cardsRow}>
//         {Array.from({ length: 4 }).map((_, i) => (
//           <ContentCardSkeleton key={i} />
//         ))}
//       </View>
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: { marginTop: 24, paddingLeft: 16 },
//   title: { width: 140, height: 16, marginBottom: 12 },
//   cardsRow: { flexDirection: 'row' },
// });
import { View } from 'react-native';
import Skeleton from '../common/Skeleton';
import ContentCardSkeleton from './ContentCardSkeleton';

export default function ContentRowSkeleton() {
  return (
    <View className="mt-6 pl-4">
      <Skeleton style={{ width: 140, height: 16, marginBottom: 12 }} />
      <View className="flex-row">
        {Array.from({ length: 4 }).map((_, i) => (
          <ContentCardSkeleton key={i} />
        ))}
      </View>
    </View>
  );
}