

// import { memo } from 'react';
// import { TouchableOpacity, Image, Text, View } from 'react-native';
// import { useRouter } from 'expo-router';
// import { ContentItem } from '../../types/content';

// interface ContentCardProps {
//   item: ContentItem;
// }

// function ContentCard({ item }: ContentCardProps) {
//   const router = useRouter();

//   return (
//     <TouchableOpacity
//       activeOpacity={0.8}
//       className="w-[110px] mr-3"
//       onPress={() => router.push(`/detail/${item.id}`)}
//     >
//       <Image
//         source={{ uri: item.posterUrl }}
//         className="w-[110px] h-[165px] rounded-lg bg-surface"
//         resizeMode="cover"
//       />

//       {item.isLive ? (
//         <View className="absolute top-1.5 left-1.5 bg-[#E50914] px-1.5 py-0.5 rounded">
//           <Text className="text-white text-[9px] font-bold">LIVE</Text>
//         </View>
//       ) : null}

//       <Text className="text-white text-xs mt-1.5" numberOfLines={1}>
//         {item.title}
//       </Text>
//     </TouchableOpacity>
//   );
// }

// export default memo(ContentCard);

import { memo } from "react";
import {
  View,
  Text,
  Image,
  TouchableOpacity,
} from "react-native";
import { useRouter } from "expo-router";
import { ContentItem } from "../../types/content";

interface Props {
  item: ContentItem;
}

function ContentCard({ item }: Props) {
  const router = useRouter();

  return (
    <TouchableOpacity
      activeOpacity={0.85}
      className="w-[110px] mr-3"
      onPress={() => router.push(`/detail/${item.id}`)}
    >
      <View className="relative">
        <Image
          source={{ uri: item.posterUrl }}
        className="w-[110px] h-[165px] rounded-lg bg-surface"
          resizeMode="cover"
        />

        {item.rating && (
          <View className="absolute right-2 top-2 rounded-full bg-black/80 px-2 py-1">
            <Text className="text-[10px] font-semibold text-yellow-400">
              ⭐ {item.rating}
            </Text>
          </View>
        )}

        {item.isLive && (
          <View className="absolute left-1.5 top-1.5 rounded-md bg-red-600 px-2 py-1">
            <Text className="text-[9px] font-bold text-white">
              LIVE
            </Text>
          </View>
        )}
      </View>

      <Text
        numberOfLines={1}
        className="mt-1.5 text-sm font-semibold text-white  numberOfLines={1}"
      >
        {item.title}
      </Text>

     
    </TouchableOpacity>
  );
}

export default memo(
  ContentCard,
  (prev, next) => prev.item.id === next.item.id
);