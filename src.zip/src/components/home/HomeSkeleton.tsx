// import { View, StyleSheet, Dimensions } from 'react-native';
// import Skeleton from '../common/Skeleton';

// const { width } = Dimensions.get('window');

// export default function HomeSkeleton() {
//   return (
//     <View style={styles.container}>
//       <Skeleton style={{ width, height: 220 }} />
//       {[1, 2, 3].map((row) => (
//         <View key={row} style={styles.row}>
//           <Skeleton style={styles.rowTitle} />
//           <View style={styles.cardsRow}>
//             {[1, 2, 3, 4].map((card) => (
//               <Skeleton key={card} style={styles.card} />
//             ))}
//           </View>
//         </View>
//       ))}
//     </View>
//   );
// }

// const styles = StyleSheet.create({
//   container: { flex: 1 },
//   row: { marginTop: 24, paddingLeft: 16 },
//   rowTitle: { width: 140, height: 18, marginBottom: 12 },
//   cardsRow: { flexDirection: 'row', gap: 12 },
//   card: { width: 110, height: 165 },
// });

import { View, StyleSheet } from 'react-native';
import HeroBannerSkeleton from './HeroBannerSkeleton';
import ContentRowSkeleton from './ContentRowSkeleton';

export default function HomeSkeleton() {
  return (
    <View style={styles.container}>
      <HeroBannerSkeleton />
      {Array.from({ length: 3 }).map((_, i) => (
        <ContentRowSkeleton key={i} />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
});