import { View, StyleSheet, Dimensions } from 'react-native';
import Skeleton from '../common/Skeleton';

const { width } = Dimensions.get('window');
const HERO_HEIGHT = 220;

export default function HeroBannerSkeleton() {
  return (
    <View style={styles.container}>
      <Skeleton style={styles.image} />
      <View style={styles.overlay}>
        <Skeleton style={styles.title} />
        <Skeleton style={styles.tagline} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { width, height: HERO_HEIGHT, position: 'relative' },
  image: { width: '100%', height: '100%', borderRadius: 0 },
  overlay: { position: 'absolute', bottom: 24, left: 16, right: 16 },
  title: { width: 180, height: 22, marginBottom: 8 },
  tagline: { width: 120, height: 13 },
});