

import { View, Text, StyleSheet } from 'react-native';
import { useLocalSearchParams } from 'expo-router';

export default function DetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  return (
    <View className="flex-1 bg-[#0F1014] justify-center items-center">
      <Text className="text-white">Detail for ID: {id}</Text>
    </View>
  );
}

